TJWS 1.94
Change to ./bin directory and start tjws.bat, tjws.sh, 
or tjws.lnk in dependency on your OS.
Access server at http://localhost, or http://localhost:8080 (on Unix/Linux/Mac)

Check TJWS home at http://tjws.sf.net
