package java.util;
public interface Set {
}