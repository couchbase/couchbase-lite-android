package java.util;
public interface Map {
}